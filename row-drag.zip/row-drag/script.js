let table = new DataTable('#myTable');

$(document).ready(()=>{
    const storedOrderData = localStorage.getItem('orderData');
    let initialOrderData = storedOrderData ? JSON.parse(storedOrderData) : [];
    
    UpdateUIWithOrder(initialOrderData);


    // sort
    $('.row_position_move').sortable({
        delay:150,
        stop(){
            const selectData = new Array();
            
            $('.row_position_move>tr').each(function(){
                selectData.push($(this).attr('id'));
            });
            updateOrder(selectData);
        }
    });



    //update row order 
    function updateOrder(selectData){
        localStorage.setItem('orderData', JSON.stringify(selectData));
    }

function UpdateUIWithOrder(order) {
    const tableBody = $('.row_position_move');

 
    const idToRowMap = {};
    tableBody.children('tr').each(function () {
        const id = $(this).attr('id');
        idToRowMap[id] = $(this);
    });


    tableBody.empty();


    order.forEach((itemId) => {
        const row = idToRowMap[itemId];
        if (row) {
            tableBody.append(row);
        }
    });
}





});